<?php
session_start();

define ('CODEKIR', 'Version 1.0');

define ('COREPATH', 'engine/');

require_once (COREPATH.'system.php');


?>
