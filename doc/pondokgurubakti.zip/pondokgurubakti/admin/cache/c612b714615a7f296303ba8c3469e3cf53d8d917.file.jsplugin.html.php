<?php /* Smarty version Smarty-3.1.15, created on 2015-06-04 13:52:48
         compiled from "./view/template/jsplugin.html" */ ?>
<?php /*%%SmartyHeaderCode:176216159755237ac65597d1-09078083%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c612b714615a7f296303ba8c3469e3cf53d8d917' => 
    array (
      0 => './view/template/jsplugin.html',
      1 => 1432624380,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '176216159755237ac65597d1-09078083',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_55237ac6560904_55123834',
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55237ac6560904_55123834')) {function content_55237ac6560904_55123834($_smarty_tpl) {?><!--JAVASCRIPT-->
	<!--=================================================-->
	
	<!--Nifty Admin [ RECOMMENDED ]-->
	<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/nifty.min.js"></script>


	<!--Demo script [ DEMONSTRATION ]-->
	<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/demo/nifty-demo.min.js"></script>

	<!--DataTables Sample [ SAMPLE ]-->
	<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/demo/tables-datatables.js"></script>

	<!--Form Component [ SAMPLE ]-->
	<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/demo/form-component.js"></script>
<?php }} ?>
