<?php /* Smarty version Smarty-3.1.15, created on 2015-04-07 13:23:06
         compiled from "./view/jsplugin.html" */ ?>
<?php /*%%SmartyHeaderCode:287367282552377ca08c995-50850075%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '913a4d176b933958468dc3222708b1b3c9549938' => 
    array (
      0 => './view/jsplugin.html',
      1 => 1428206454,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '287367282552377ca08c995-50850075',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_552377ca0c9633_99225887',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_552377ca0c9633_99225887')) {function content_552377ca0c9633_99225887($_smarty_tpl) {?><script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/libs/jquery-1.9.1.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/libs/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/libs/bootstrap.min.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/parsley/parsley.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/icheck/jquery.icheck.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/simplecolorpicker/jquery.simplecolorpicker.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/select2/select2.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/autosize/jquery.autosize.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/textarea-counter/jquery.textarea-counter.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/fileupload/bootstrap-fileupload.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/tableCheckable/jquery.tableCheckable.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/datatables/DT_bootstrap.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/App.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/libs/raphael-2.1.2.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/morris/morris.min.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/demos/charts/morris/area.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/demos/charts/morris/donut.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/sparkline/jquery.sparkline.min.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/fullcalendar/fullcalendar.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/WYSIWYG/jquery-te-1.4.0.min.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/demos/calendar.js"></script>

<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/magnific/jquery.magnific-popup.min.js"></script>


<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/jquery.prettyPhoto.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/wow.min.js"></script>
<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/main.js"></script>




<?php }} ?>
