<?php /* Smarty version Smarty-3.1.15, created on 2015-06-04 14:00:48
         compiled from "./view/template/footer.html" */ ?>
<?php /*%%SmartyHeaderCode:512866755237acd855c77-59567098%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '939f1dafce42733af1bfbdbddcfeee54b7a39382' => 
    array (
      0 => './view/template/footer.html',
      1 => 1432624380,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '512866755237acd855c77-59567098',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_55237acd8571c2_74917301',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55237acd8571c2_74917301')) {function content_55237acd8571c2_74917301($_smarty_tpl) {?>
		<!-- FOOTER -->
		<!--===================================================-->
		<footer id="footer">

			<!-- Visible when footer positions are static -->
			<!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
			<div class="hide-fixed pull-right pad-rgt">Codekir v1.1</div>



			<!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
			<!-- Remove the class name "show-fixed" and "hide-fixed" to make the content always appears. -->
			<!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

			<p class="pad-lft">&#0169; 2015 Trinata Bhayanaka</p>



		</footer>
		<!--===================================================-->
		<!-- END FOOTER -->
<!-- SCROLL TOP BUTTON -->
		<!--===================================================-->
		<button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
		<!--===================================================-->

	
		

</body>
</html><?php }} ?>
