<?php /* Smarty version Smarty-3.1.15, created on 2015-04-07 13:30:57
         compiled from "./view/meta.html" */ ?>
<?php /*%%SmartyHeaderCode:17720887315523759e76a0b3-25688114%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c5aa3f8b03a04dea8dac5499f0588195de041ec0' => 
    array (
      0 => './view/meta.html',
      1 => 1428388117,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17720887315523759e76a0b3-25688114',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5523759e7db069_10426085',
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5523759e7db069_10426085')) {function content_5523759e7db069_10426085($_smarty_tpl) {?><!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
    <title>Admin</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="">
	<meta name="author" content="" />
	
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
css/googleapis.css" type="text/css">

	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
css/font-awesome.min.css" type="text/css" />		
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
css/bootstrap.min.css" type="text/css" />
		
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/libs/css/ui-lightness/jquery-ui-1.9.2.custom.css" type="text/css" />
		
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/icheck/skins/minimal/blue.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/datepicker/datepicker.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/select2/select2.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/simplecolorpicker/jquery.simplecolorpicker.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/datatables/DT_bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/timepicker/bootstrap-timepicker.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/fileupload/bootstrap-fileupload.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/fullcalendar/fullcalendar.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/WYSIWYG/jquery-te-1.4.0.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
js/plugins/magnific/magnific-popup.css" type="text/css" />	
	<link href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
css/prettyPhoto.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
css/App.css" type="text/css" />

	<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
css/custom.css" type="text/css" />	
	
	
	<style>
		.btn,
		.btn-group {
			margin: 0 10px 15px 0;
		}

		.btn-block {
			margin-right: 0;
			margin-left: 0;
		}

		.btn-group .btn {
			margin: 0;
		}
	</style>
	
	<script>
		var basedomain = "<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
";
	</script>
</head><?php }} ?>
