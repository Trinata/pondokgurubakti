<?php
// defined ('TATARUANG') or exit ( 'Forbidden Access' );


require_once ('config/config.php');
require_once ('config/routes.php');
require_once (APP.'config/libs.conf.php');
require_once (APP.'config/locale.php');
require_once (APP.COREPATH.'helper.php');
require_once (APP.COREPATH.'common.php');
require_once (APP.COREPATH.'class_db.php');
require_once (APP.COREPATH.'class_session.php');
require_once (APP.LIBS . 'smarty/Smarty.class.php');
require_once (APP.COREPATH.'application.php');
require_once (APP.COREPATH.'controller.php');

?>
