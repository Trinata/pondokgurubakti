<?php

/* 
	list menu yang akan dipanggil oleh APP 
	hanya class yang ada di routes dibawah ini yang dijalankan oleh aplikasi
*/

$ROUTES = array(
		'home',
		'register',
                'recovery',
                'kontak',
                'gallery',
                'kepakaran',
                'paket',
                'login',
                'user'
        );
?>

