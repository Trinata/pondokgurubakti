<?php
session_start();

define ('APP', '../');
define ('COREPATH', 'engine/');

require_once (COREPATH.'system.php');


?>
