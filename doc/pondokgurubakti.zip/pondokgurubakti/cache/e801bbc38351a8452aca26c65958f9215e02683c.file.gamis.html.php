<?php /* Smarty version Smarty-3.1.15, created on 2015-04-01 16:13:15
         compiled from "app/view/paket/gamis.html" */ ?>
<?php /*%%SmartyHeaderCode:2083761867551bb558394a19-56136429%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e801bbc38351a8452aca26c65958f9215e02683c' => 
    array (
      0 => 'app/view/paket/gamis.html',
      1 => 1427879530,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2083761867551bb558394a19-56136429',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_551bb5583f33a2_83725313',
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_551bb5583f33a2_83725313')) {function content_551bb5583f33a2_83725313($_smarty_tpl) {?>
		<div class="container">
			<div class="product_banner">
			
				<div class="in-product">
				<div class="wmuSlider example1" style="height: 452px;">
			   <div class="wmuSliderWrapper">
				   <article style="position: absolute; width: 100%; opacity: 0;"> 
				   	 <div class="banner-wrap">
				   	       <div class="banner_left">
				   	       	  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/13.png" class="img-responsive" alt="">
				   	       </div>				   		 
				   	  </div>
					</article>
				    <article style="position: absolute; width: 100%; opacity: 0;"> 
				   	   <div class="banner-wrap">
				   	       <div class="banner_left">
				   	       	  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/13.png" class="img-responsive" alt="">
				   	       </div>			   		 	
				   	  </div>
				   </article>
				   <article style="position: relative; width: 100%; opacity: 1;">
				   	 <div class="banner-wrap">
				   	       <div class="banner_left">
				   	       	  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/13.png" class="img-responsive" alt="">
				   	       </div>				   		 	
				   	  </div>
					 </article>
				 </div>
            <a class="wmuSliderPrev">Previous</a>
			<a class="wmuSliderNext">Next</a>
			</div>
            <script src="js/jquery.wmuSlider.js"></script> 
			  <script>       			
       			$('.example1').wmuSlider({
					 pagination:false,
				});         
   		     </script>
<!---->
	</div>
				<div class="banner_right">
				   	<h3>Lorem ipsum dolor</h3>
				   	<p class="nine"></p>
				   	<p class="sit-in">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim</p>
				   	
				   		 	</div>	
			<div class="clearfix"></div>							
	</div>			 
   <!---->
   <div class="products_top">
     	
     		<div class="col-md-9 price-on">
			<!---->
     			<div class="mens-toolbar">
                 <div class="sort">
               	   <div class="sort-by">
		            <label>Sort by</label>
		            <select>
		                            <option value="">
		                    Position                </option>
		                            <option value="">
		                    Name                </option>
		                            <option value="">
		                    Price                </option>
		            </select>
		            <a href=""><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/arrow2.gif" alt="" class="v-middle"></a>
                   </div>
    		     </div>
    		    <div class="pages">   
        	      <div class="limiter visible-desktop">
	               <label>Showing 1-12 of 347 results</label>
	              </div>
       	          <ul class="dc_pagination dc_paginationA dc_paginationA06">
					  <li><a href="#">1</a></li>
					  <li><a href="#">2</a></li>
					  <li><a href="#">3</a></li>
					  <li><a href="#" class="current"></a></li>
		       		</ul>
		  	      <div class="clearfix"></div>
		  	    </div>
                <div class="clearfix"></div>		
		        </div>
				<!---->
		      <div class="product_box1">   
		        <div class="col-md-4 grid-4">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				<div class="col-md-4 grid-4">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po5.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				<div class="col-md-4 grid-4 grid-in">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po1.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				 
				<div class="col-md-4 grid-4">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po6.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				<div class="col-md-4 grid-4">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po2.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				<div class="col-md-4 grid-4 grid-in">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po3.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>					
				  
				<div class="col-md-4 grid-4">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po4.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				<div class="col-md-4 grid-4">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po5.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				<div class="col-md-4 grid-4 grid-in">
          		  <a href="single.html">
					  <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/po.jpg" class="img-responsive" alt="">
					   </a>
					   <div class="tab_desc1">
					   <h3><a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail">Feel Tank</a></h3>
						 <p></p>
						 <a href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
paket/batik/detail" class="to-cart"><span>Lihat Selengkapnya</span></a>
					   </div>
				</div>
				  <div class="clearfix"></div>
			  </div>
			
			  <!---->
			  <div class="pages">   
        	     <div class="limiter visible-desktop">
	               <label>Showing 1-12 of 347 results</label>
	             </div>
       	         <ul class="dc_pagination dc_paginationA dc_paginationA06">
					<li><a href="#">1</a></li>
					<li><a href="#">2</a></li>
					<li><a href="#">3</a></li>
					<li><a href="#" class="current"></a></li>
		       	  </ul>
		  	      <div class="clearfix"></div>
		  	   </div>
			   <!---->
     		</div>
     		<div class="col-md-3 product_right">
				<h3 class="m_1">On Sale</h3>
				 <div class="sale_grid">
				  <ul class="grid_1">
					<li class="grid_1-img"><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/s1.jpg" class="img-responsive" alt=""></li>
					<li class="grid_1-desc">
					  <h4><a href="#">Pintuck Tank</a></h4>
					  <p>$45.55</p>
					</li>
					<div class="clearfix"> </div>
				  </ul>
				  <ul class="grid_1">
					<li class="grid_1-img"><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/s2.jpg" class="img-responsive" alt=""></li>
					<li class="grid_1-desc">
					  <h4><a href="#">Pintuck Tank</a></h4>
					  <p>$45.55</p>
					</li>
					<div class="clearfix"> </div>
				  </ul>
				  <ul class="grid_1">
					<li class="grid_1-img"><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/s3.jpg" class="img-responsive" alt=""></li>
					<li class="grid_1-desc">
					  <h4><a href="#">Pintuck Tank</a></h4>
					  <p>$45.55</p>
					</li>
					<div class="clearfix"> </div>
				  </ul>
				</div>
			   <h3 class="m_1">Featured Products</h3>
			      <div class="sale_grid">
				  <ul class="grid_1">
					<li class="grid_1-img"><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/s2.jpg" class="img-responsive" alt=""></li>
					<li class="grid_1-desc">
					  <h4><a href="#">Pintuck Tank</a></h4>
					  <p>$45.55</p>
					</li>
					<div class="clearfix"> </div>
				  </ul>
				  <ul class="grid_1">
					<li class="grid_1-img"><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/s4.jpg" class="img-responsive" alt=""></li>
					<li class="grid_1-desc">
					  <h4><a href="#">Pintuck Tank</a></h4>
					  <p>$45.55</p>
					</li>
					<div class="clearfix"> </div>
				  </ul>
				  <ul class="grid_1">
					<li class="grid_1-img"><img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/s3.jpg" class="img-responsive" alt=""></li>
					<li class="grid_1-desc">
					  <h4><a href="#">Pintuck Tank</a></h4>
					  <p>$45.55</p>
					</li>
					<div class="clearfix"> </div>
				  </ul>
				</div>
				  <div class="clearfix"> </div>
     		</div>
			<div class="clearfix"> </div>
      </div>
	</div>
<?php }} ?>
