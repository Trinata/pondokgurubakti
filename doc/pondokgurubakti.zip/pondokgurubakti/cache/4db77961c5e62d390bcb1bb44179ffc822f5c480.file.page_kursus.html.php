<?php /* Smarty version Smarty-3.1.15, created on 2015-06-04 14:46:10
         compiled from "app/view/kursus/page_kursus.html" */ ?>
<?php /*%%SmartyHeaderCode:8679799945564287e083b41-63851295%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4db77961c5e62d390bcb1bb44179ffc822f5c480' => 
    array (
      0 => 'app/view/kursus/page_kursus.html',
      1 => 1433403968,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8679799945564287e083b41-63851295',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_5564287e0a14d2_68411729',
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5564287e0a14d2_68411729')) {function content_5564287e0a14d2_68411729($_smarty_tpl) {?><section class="callaction">
	<div class="container">
		<div class="row">
			<div class="col-md-8" style="background-color:#AF0096">
				<div class="row">
					<div class="col-md-1" style="padding-top:20px">
						<div style="color:#FFFFFF;background-color:#73496E;padding:10px">
							<i class="fa fa-file-text fa-3"></i>
						</div>
					</div>
					<div class="col-md-10"  style="color:#FFFFFF;height:287px">
						<h1  style="color:#FFFFFF">What Is Lorem Ipsum</h1>
						Lorem ipsum dolor sit amet, consectetur consectetur adipiscing elit donec mer lacinia. adipiscing elit donec mer lacinia
						<ol type="1">
							<li>Lorem ipsum dolor sit amet, consectetu</li>
							<li>Lorem ipsum dolor sit amet, consectetu</li>
							<li>Lorem ipsum dolor sit amet, consectetu</li>
							<li>Lorem ipsum dolor sit amet, consectetu</li>
							<li>Lorem ipsum dolor sit amet, consectetu</li>
						</ol>
					</div>
				</div>
			</div>
			<div class="col-md-3" align="center" style="color:#FFFFFF;background-color:#D3D3D3;padding-top:10px;margin-left:5px;border-radius:5px;">
				<img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/img/data/iconslide.JPG"/><br/><br/>
				<span style="font-size:24px;color:#252A72">E-Elearning Standarisasi & Penilaian Kesesuaian</span>
				<br/><span style="color:#000000">10 Pokok Bahasan</span><br/><br/>
				   <div style="border-radius:5px 10px;background-color:#4155D0;width:100%;height:100%;padding:10px 0px;"><a href="#" style="text-decoration:none;color:#FFFFFF;font-size:24px;">APPLY NOW
                        </a></div>
			</div>

		</div>
	</div>
	</section>
	<section class="callaction">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="btn-group" role="group" aria-label="..." style="font-size:21px">
				  <a href="#" class="btn btn-primary hvr-bubble-bottom">COURSE BRIEF</a>
				  <a href="#" class="btn btn-primary hvr-bubble-bottom">MATERI</a>
				  <a href="#" class="btn btn-primary hvr-bubble-bottom">DOWNLOAD</a>
				  <a href="#" class="btn btn-primary hvr-bubble-bottom">VIDEO</a>
				  <a href="#" class="btn btn-primary hvr-bubble-bottom">FAQS</a>
				</div><br/><br/><br/>
				<div class="row">
					<div class="col-md-3">
						<div class="btn-group-vertical" role="group" aria-label="..." align="left">
						  
							  <a href="#" class="btn btn-default" disabled><i class="fa fa-list"></i> Pokok  Bahasan</a>
							  <a href="#" class="btn btn-default">Pengantar</a>
							  <a href="#" class="btn btn-default">Cakupan Standar</a>
							  <a href="#" class="btn btn-default">Infrastruktur Mutu</a>
							  <a href="#" class="btn btn-default">Prinsip Dasar Pengembangan</a>
							  <a href="#" class="btn btn-default">Proses Pengembangan Standar</a>
							  <a href="#" class="btn btn-default">Sistem Penerapan Standar</a>
							  <a href="#" class="btn btn-default">Penilaian Kesesuaian</a>
							  <a href="#" class="btn btn-default">Manfaat Ekonomi Standar</a>
						</div>
					</div>

					<div class="col-md-8">
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Tujuan
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Waktu
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Sub Pokok Bahasan
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseThree">
          Referensi
        </a>
      </h4>
    </div>
    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
        Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
      </div>
    </div>
  </div>
</div>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				&nbsp;
			</div>

		</div>
	</div>
	</section><?php }} ?>
