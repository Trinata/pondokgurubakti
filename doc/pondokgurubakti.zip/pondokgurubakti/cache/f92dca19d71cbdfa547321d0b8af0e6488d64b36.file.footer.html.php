<?php /* Smarty version Smarty-3.1.15, created on 2015-06-29 14:19:21
         compiled from "app/view/template/footer.html" */ ?>
<?php /*%%SmartyHeaderCode:400916135551baaf9679b19-25236715%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f92dca19d71cbdfa547321d0b8af0e6488d64b36' => 
    array (
      0 => 'app/view/template/footer.html',
      1 => 1435561463,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '400916135551baaf9679b19-25236715',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_551baaf9681663_42054093',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_551baaf9681663_42054093')) {function content_551baaf9681663_42054093($_smarty_tpl) {?>
        <!-- footer -->
        <div class="footer">
            <!-- container -->
            <div class="container">
                <div class="footer-left">
                    <p>Design by <a href="http://trinata.com/">Trinata Teknologi</a></p>
                </div>
                <div class="footer-right">
                    <div class="footer-nav">
                        <ul>
                            <li><a href="#">Beranda</a></li>                                                  
                            <li><a href="#">Tentang Kami</a></li>  
                            <li><a href="#">BOOKING Kamar</a></li>  
                            <li><a href="#">Berita</a></li>  
                            <li><a href="#">Kontak</a></li>  
                        </ul>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
            <!-- //container -->
        </div>
        <!-- //footer -->
        <script type="text/javascript">
                                    $(document).ready(function() {
                                        /*
                                        var defaults = {
                                            containerID: 'toTop', // fading element id
                                            containerHoverID: 'toTopHover', // fading element hover id
                                            scrollSpeed: 1200,
                                            easingType: 'linear' 
                                        };
                                        */
                                        
                                        $().UItoTop({ easingType: 'easeOutQuart' });
                                        
                                    });
                                </script>
                                    <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
    <!-- content-Get-in-touch -->
    </body>
</html><?php }} ?>
