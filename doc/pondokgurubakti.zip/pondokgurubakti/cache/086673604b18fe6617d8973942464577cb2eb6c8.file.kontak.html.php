<?php /* Smarty version Smarty-3.1.15, created on 2015-08-18 06:20:19
         compiled from "app/view/kontak/kontak.html" */ ?>
<?php /*%%SmartyHeaderCode:158129639255d150616eabc5-93511999%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '086673604b18fe6617d8973942464577cb2eb6c8' => 
    array (
      0 => 'app/view/kontak/kontak.html',
      1 => 1439853616,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '158129639255d150616eabc5-93511999',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_55d15061844687_69420160',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55d15061844687_69420160')) {function content_55d15061844687_69420160($_smarty_tpl) {?><!-- mail -->
		<div class="mail">
			<!-- container -->
			<div class="container">
				<div class="mail-info">
					<h3>OUR LOCATION</h3>
				</div>
				<div class="map">
					<iframe src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=City+of+Westminster,+United+Kingdom&amp;aq=0&amp;oq=westmi&amp;sll=51.50917,-0.245132&amp;sspn=0.311545,0.837021&amp;ie=UTF8&amp;hq=&amp;hnear=City+of+Westminster,+Greater+London,+United+Kingdom&amp;ll=51.483521,-0.082054&amp;spn=0.155803,0.41851&amp;t=m&amp;z=12&amp;output=embed"></iframe>
				</div>
				<div class="mail-info-grids">
					<div class="col-md-6 mail-info-grid">
						<h3>Contact Information</h3>
						<p>In pharetra dui vitae odio maximus vulputate. Nul
							am finibus dui more neque dui vitae odio maximu.
							In pharetra dui vitae odio maximus vulputate. Null
							finibus dui more neque.odio maximus vulputate. 
							Nulla odio maximus vulputate. Nulla odio maxi.
						</p>
						<h6>The Company Name agi.
						<span>756 gt globel Place,</span>
							CD-Road,M 07 435.
						</h6>
						<p>Telephone: +1 234 567 9871
						<span>FAX: +1 234 567 9871</span>
						E-mail: <a href="mailto:info@example.com">mail@example.com</a>
						</p>
					</div>
					<div class="col-md-6 contact-form">
						<form>
							<input type="text" placeholder="Name:" required="">
							<input type="text" placeholder="Email:" required="">
							<input type="text" placeholder="Subject:" required="">
							<textarea placeholder="Message:" required=""></textarea>
							<input type="submit" value="SEND">
						</form>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<!-- //container -->
		</div>
		<!-- //mail -->
			    <!--  <div class="map">
				 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d505145.6949089349!2d115.07157704999999!3d-8.455471450000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd22f7520fca7d3%3A0x2872b62cc456cd84!2sBali%2C+Indonesia!5e0!3m2!1sen!2sin!4v1418170815897"></iframe>
				</div>
      		</div>
		    </div> -->

	<?php }} ?>
