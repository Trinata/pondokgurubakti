<?php /* Smarty version Smarty-3.1.15, created on 2015-06-29 14:46:28
         compiled from "app/view/profil/page_profil.html" */ ?>
<?php /*%%SmartyHeaderCode:2132477476555dc4220087b4-13700273%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a7c160ef610a46e77e2887695d7099ed6431755' => 
    array (
      0 => 'app/view/profil/page_profil.html',
      1 => 1435563774,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2132477476555dc4220087b4-13700273',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_555dc422038654_41004404',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_555dc422038654_41004404')) {function content_555dc422038654_41004404($_smarty_tpl) {?><!-- about -->
			<div class="about">
				<!-- container -->
				<div class="container">
					<div class="about-info">
						<h3>about us</h3>
						<h4>Quisque lectus ipsum, fermentum eu sodales non, auctor in mauris. Nulla pretium cursus nulla, ac rutrum magna laoreet eu.
							Phasellus vel est vel odio finibus lacinia. Donec a diam dictum, elementum ipsum et, pulvina
						</h4>
						<p>Duis vulputate auctor libero, eget viverra ante dapibus sit amet. Vestibulum auctor pellentesque enim, 
						sed ornare metus vehicula eu. Etiam rhoncus eu urna ac feugiat. Praesent sed tempor urna, laoreet dignissim est. 
						Aenean nec justo vitae arcu consequat lobortis. Sed iaculis et dui eu sollicitudin. Morbi id felis porttitor tellus 
						viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam cursus 
						leo nec enim vulputate finibus. Nulla at dui non nisi molestie posuere non sed ante. 
						Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.Nulla at dui non nisi molestie posuere non sed ante. </p>
					</div>
				</div>
				<!-- //container -->
			</div>
			<!-- about -->
			<!-- about-banner -->
			<div class="about-banner">
				<div class="banner-bg">
					<h3>WE OFFER!</h3>
					<div class="read-more">
						<a href="#">SEE THE TOUR</a>
					</div>
				</div>
			</div>
			<!-- about-banner -->
			<!-- team -->
			<div class="team">
				<!-- container -->
				<div class="container">
					<div class="team-info">
						<h3>OUR TEAM</h3>
					</div>
					<div class="team-grids">
						<div class="team-grid">
							<img src="images/7.jpg" alt="" />
							<div class="team-grid-info">
								<h4>MELISSA DOE</h4>
								<p>Class aptent taciti sociosqu ad litora torquent per conu-
									bia nostra, per inceptos himenaeos.
								</p>
							</div>
						</div>
						<div class="team-grid">
							<img src="images/8.jpg" alt="" />
							<div class="team-grid-info">
								<h4>MELISSA DOE</h4>
								<p>Class aptent taciti sociosqu ad litora torquent per conu-
									bia nostra, per inceptos himenaeos.
								</p>
							</div>
						</div>
						<div class="team-grid">
							<img src="images/9.jpg" alt="" />
							<div class="team-grid-info">
								<h4>MELISSA DOE</h4>
								<p>Class aptent taciti sociosqu ad litora torquent per conu-
									bia nostra, per inceptos himenaeos.
								</p>
							</div>
						</div>
						<div class="team-grid">
							<img src="images/10.jpg" alt="" />
							<div class="team-grid-info">
								<h4>MELISSA DOE</h4>
								<p>Class aptent taciti sociosqu ad litora torquent per conu-
									bia nostra, per inceptos himenaeos.
								</p>
							</div>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
				<!-- container -->
			</div><?php }} ?>
