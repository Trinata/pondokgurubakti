<?php /* Smarty version Smarty-3.1.15, created on 2015-06-29 14:30:26
         compiled from "app/view/home.html" */ ?>
<?php /*%%SmartyHeaderCode:651081253551bab75b9a6d5-47799625%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20ea44c36004ad3e6ed8c39381667b05fbd78d26' => 
    array (
      0 => 'app/view/home.html',
      1 => 1435563025,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '651081253551bab75b9a6d5-47799625',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_551bab75bd8051_80366675',
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_551bab75bd8051_80366675')) {function content_551bab75bd8051_80366675($_smarty_tpl) {?><!-- banner-grids -->
        <div class="banner-grids">
            <!-- container -->
            <div class="container">
                <div class="banner-grid-info">
                    <h3 >Top Destinations</h3>
                    <p>Lombok</p>
                </div>
                <div class="top-grids">
                    <div class="top-grid">
                        <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/images/destinasi/rinjani.jpg" alt="" />
                        <div class="top-grid-info">
                            <h3>Mount Rinjani</h3>
                            <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
                        </div>
                    </div>
                    <div class="top-grid">
                        <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/images/destinasi/taman.png" alt="" />
                        <div class="top-grid-info">
                            <h3>Rinjani National Park</h3>
                            <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
                        </div>
                    </div>
                    <div class="top-grid">
                        <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/images/destinasi/tiu-kelep.jpg" alt="" />
                        <div class="top-grid-info">
                            <h3>Tiu Kelep Waterfall</h3>
                            <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
                        </div>
                    </div>
                    <div class="top-grid">
                        <img src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/images/destinasi/Sendang-Gile.jpg" alt="" />
                        <div class="top-grid-info">
                            <h3>Sendang Gile Waterfall</h3>
                            <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices .</p>
                        </div>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <!-- //container -->
        </div>
        <!-- //banner-grids -->
        <!-- before -->
        <div class="before">
            <!-- container -->
            <div class="container">
                <h2>Before you leave</h2>
                <div class="before-grids">
                    <div class="before-grid">
                        <h3>visa & documents</h3>
                        <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
                            Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
                        </p>
                    </div>
                    <div class="before-grid">
                        <h3>visa & documents</h3>
                        <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
                            Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
                        </p>
                    </div>
                    <div class="before-grid">
                        <h3>visa & documents</h3>
                        <p>Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
                            Morbi id felis porttitor tellus viverra pulvinar. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices.
                        </p>
                    </div>
                    <div class="clearfix"> </div>
                    <!--<div class="search">
                        <p>get hottest deals to your inbox</p>
                        <form>
                            <input type="text" placeholder="Email address" required="">
                            <input type="submit" value="Subscribe">
                        </form>
                    </div>-->
                </div>
            </div>
            <!-- //container -->
        </div>
        <!-- //before --><?php }} ?>
