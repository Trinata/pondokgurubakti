<?php /* Smarty version Smarty-3.1.15, created on 2015-06-29 14:15:57
         compiled from "app/view/template/meta.html" */ ?>
<?php /*%%SmartyHeaderCode:418757163551baaf9647630-17809719%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '454a1cf33b1da26a920fc436305f78936f7bcecf' => 
    array (
      0 => 'app/view/template/meta.html',
      1 => 1435562150,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '418757163551baaf9647630-17809719',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_551baaf965bf42_87504422',
  'variables' => 
  array (
    'basedomain' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_551baaf965bf42_87504422')) {function content_551baaf965bf42_87504422($_smarty_tpl) {?><!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
	<head>
		<title>Pondok Guru Bakti | Penginapan</title>
		<link href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/css/style.css" rel="stylesheet" type="text/css" media="all" />
		<link href="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
		<!-- web-font -->
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Playball' rel='stylesheet' type='text/css'>
		<!-- web-font -->
		<!-- js -->
		<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/js/jquery.min.js"></script>
		<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/js/modernizr.custom.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<script type="application/x-javascript">
		
		 addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 

		
		 </script>
		<!-- js -->
		<script src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/js/modernizr.custom.js"></script>
		<!-- start-smoth-scrolling -->
		<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/js/move-top.js"></script>
		<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
assets/js/easing.js"></script>
		<script type="text/javascript">

		
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});

		
		</script>
		<!-- start-smoth-scrolling -->
<script type="text/javascript">
	var basedomain = "<?php echo $_smarty_tpl->tpl_vars['basedomain']->value;?>
";
</script>
</head>
<body><?php }} ?>
