<?php /* Smarty version Smarty-3.1.15, created on 2015-04-01 15:23:21
         compiled from "app/view/landing.html" */ ?>
<?php /*%%SmartyHeaderCode:1572858068551baaf961b637-76687307%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f2f42959b8961cb4259a4d1ef2d2fca1b99d8cfb' => 
    array (
      0 => 'app/view/landing.html',
      1 => 1427876452,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1572858068551baaf961b637-76687307',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_551baaf961caf2_30938964',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_551baaf961caf2_30938964')) {function content_551baaf961caf2_30938964($_smarty_tpl) {?><?php }} ?>
