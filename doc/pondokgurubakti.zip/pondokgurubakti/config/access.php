<?php
/* Konfigurasi DB */

$dbConfig[0]['host'] = 'localhost';
$dbConfig[0]['user'] = 'root';
$dbConfig[0]['pass'] = 'jonedganteng';
$dbConfig[0]['name'] = 'db_elearningbsn';
$dbConfig[0]['server'] = 'mysql';

?>