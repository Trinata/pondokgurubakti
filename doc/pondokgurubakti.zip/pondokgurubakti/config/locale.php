<?php

$LOCALE['default']['error']['debug'] = "App on debug mode";
$LOCALE['default']['error']['missingtemplate'] = "Your master template not available in view folder";
$LOCALE['default']['footer'] = "2013, Codekir Framework";
$LOCALE['default']['upload_xls_error'] = "data not valid, please check your xls template";
?>
